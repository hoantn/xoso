✅ Hướng dẫn sử dụng Xổ Số 1995 Backend (Tiếng Việt)

1. Cài đặt:
- npm install

2. Chạy thử local:
- npm start

3. Các API chính:
- POST /api/register - Đăng ký
- POST /api/login - Đăng nhập
- GET /api/profile - Thông tin người dùng
- POST /api/deposit - Nạp tiền
- POST /api/bet/:type - Đặt cược
- GET /api/lottery/:type/current - Xem kết quả hiện tại

4. Deploy miễn phí tại Render.com
- Kết nối GitHub -> Deploy Node.js